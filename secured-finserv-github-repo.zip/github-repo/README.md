# Secured Finserv - Official Website

## About
Secured Finserv is an independent loan advisory platform based in Mangalore, serving clients across Pan India. We connect businesses and professionals with 20+ leading banks and NBFCs for the best loan deals.

## Website
**Live URL:** https://securedfinserv.com

## Features
- Modern Gen-Z dark theme design
- Purple & Gold color scheme
- Glassmorphism UI effects
- Lead capture form
- WhatsApp integration
- Mobile responsive
- SSL enabled (HTTPS)

## Services
- Business Loans (5L - 2Cr)
- Professional Loans (2L - 50L)
- Loan Against Property (10L - 5Cr)

## Contact
- **Phone/WhatsApp:** +91 96864 49486
- **Email:** securedfintech@gmail.com
- **Address:** River Oaks Building, 1st Floor, Kuloor-Kavoor Road, Mangalore - 575015

## Tech Stack
- React + TypeScript
- Tailwind CSS
- Netlify Hosting
- Custom Domain (securedfinserv.com)
